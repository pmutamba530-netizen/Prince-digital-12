import "./styles.css";

export const metadata = {
  title: "Prince Digital",
  description: "Services numériques, IA et solutions digitales.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
