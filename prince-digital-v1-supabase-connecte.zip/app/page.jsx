 "use client";

import { useEffect, useState } from "react";
import { createClient } from "../lib/supabase-browser";

const whatsapp = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "243993354646";

export default function Home() {
  const supabase = createClient();
  const [services, setServices] = useState([]);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState("signup");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadServices();
  }, []);

  async function loadServices() {
    const { data, error } = await supabase
      .from("services")
      .select("id,name,description,price,currency")
      .eq("active", true)
      .order("created_at", { ascending: true });

    if (error) setMessage("Impossible de charger les services : " + error.message);
    else setServices(data || []);
  }

  async function submitAuth(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    const result = mode === "signup"
      ? await supabase.auth.signUp({ email, password })
      : await supabase.auth.signInWithPassword({ email, password });

    if (result.error) setMessage(result.error.message);
    else setMessage(mode === "signup"
      ? "Compte créé. Vérifie ton e-mail si la confirmation est activée."
      : "Connexion réussie.");
    setLoading(false);
  }

  function order(service) {
    const text = encodeURIComponent(
      `Bonjour Prince Digital, je souhaite commander : ${service.name} (${service.price} ${service.currency}).`
    );
    window.open(`https://wa.me/${whatsapp}?text=${text}`, "_blank");
  }

  return (
    <main>
      <header className="hero">
        <div className="nav">
          <strong>PRINCE DIGITAL</strong>
          <a href={`https://wa.me/${whatsapp}`} target="_blank">WhatsApp</a>
        </div>
        <div className="heroContent">
          <span className="badge">Solutions numériques</span>
          <h1>Vos besoins numériques,<br/>une seule adresse.</h1>
          <p>Services digitaux, création, IA et accompagnement pour particuliers et entreprises.</p>
          <a className="button" href="#services">Découvrir nos services</a>
        </div>
      </header>

      <section id="services" className="section">
        <div className="sectionHead">
          <div><span className="eyebrow">SERVICES</span><h2>Ce que nous proposons</h2></div>
          <span className="status">● Supabase connecté</span>
        </div>
        <div className="grid">
          {services.length === 0 ? <p>Chargement des services...</p> : services.map(s => (
            <article className="card" key={s.id}>
              <h3>{s.name}</h3>
              <p>{s.description}</p>
              <div className="price">{s.price} {s.currency}</div>
              <button onClick={() => order(s)}>Commander</button>
            </article>
          ))}
        </div>
      </section>

      <section className="section authSection">
        <div>
          <span className="eyebrow">ESPACE CLIENT</span>
          <h2>{mode === "signup" ? "Créer votre compte" : "Se connecter"}</h2>
          <p>Votre compte servira ensuite à suivre commandes, fichiers, paiements et notifications.</p>
        </div>
        <form onSubmit={submitAuth} className="auth">
          <input type="email" placeholder="Votre e-mail" value={email} onChange={e=>setEmail(e.target.value)} required />
          <input type="password" placeholder="Mot de passe (6 caractères minimum)" value={password} onChange={e=>setPassword(e.target.value)} minLength={6} required />
          <button disabled={loading}>{loading ? "Patientez..." : mode === "signup" ? "Créer mon compte" : "Connexion"}</button>
          <button type="button" className="linkButton" onClick={()=>setMode(mode==="signup"?"login":"signup")}>
            {mode === "signup" ? "J'ai déjà un compte" : "Créer un compte"}
          </button>
          {message && <p className="message">{message}</p>}
        </form>
      </section>

      <footer>© {new Date().getFullYear()} Prince Digital — V1</footer>
    </main>
  );
}
