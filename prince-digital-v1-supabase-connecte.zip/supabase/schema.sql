create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'client' check (role in ('client','provider','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  price numeric(12,2) not null default 0,
  currency text not null default 'USD',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  service_id uuid references public.services(id) on delete set null,
  status text not null default 'pending' check (status in ('pending','paid','processing','completed','cancelled')),
  notes text,
  total numeric(12,2) not null default 0,
  currency text not null default 'USD',
  created_at timestamptz not null default now()
);

create table if not exists public.order_files (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  file_path text not null,
  file_name text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.orders enable row level security;
alter table public.order_files enable row level security;

drop policy if exists "Public can read active services" on public.services;
create policy "Public can read active services"
on public.services for select using (active = true);

drop policy if exists "Users read own profile" on public.profiles;
create policy "Users read own profile"
on public.profiles for select to authenticated
using (id = auth.uid());

drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile"
on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "Users read own orders" on public.orders;
create policy "Users read own orders"
on public.orders for select to authenticated
using (user_id = auth.uid());

drop policy if exists "Users create own orders" on public.orders;
create policy "Users create own orders"
on public.orders for insert to authenticated
with check (user_id = auth.uid());

drop policy if exists "Users read own order files" on public.order_files;
create policy "Users read own order files"
on public.order_files for select to authenticated
using (
  exists (
    select 1 from public.orders o
    where o.id = order_id and o.user_id = auth.uid()
  )
);

insert into public.services (name,description,price,currency)
select * from (values
('Montage vidéo','Montage professionnel pour vidéos courtes, réseaux sociaux et présentations.',20,'USD'),
('Design graphique','Affiches, flyers et visuels publicitaires adaptés au web et aux réseaux sociaux.',10,'USD'),
('CV & documents','CV professionnels, lettres et mise en forme de documents.',5,'USD'),
('Site web','Création de site vitrine et solutions web adaptées au besoin.',50,'USD'),
('Réseaux sociaux','Création de contenus et supports pour vos réseaux sociaux.',15,'USD'),
('Prince AI','Assistance IA et automatisation de tâches numériques.',5,'USD')
) as v(name,description,price,currency)
where not exists (select 1 from public.services);
